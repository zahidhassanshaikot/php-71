<html>
<head>
    <meta charset="utf-8">
</head>
<body>
    <h1>Billing Info</h1>
    <table border="1">
        <tr>
            <th>Customer Name</th>
            <td><?php echo e($customer->first_name.' '.$customer->last_name); ?></td>
        </tr>
        <tr>
            <th>Phone Number</th>
            <td><?php echo e($customer->phone_number); ?></td>
        </tr>
    </table>
    <h1>Shipping Info</h1>
    <table border="1">
        <tr>
            <th>Customer Name</th>
            <td><?php echo e($shipping->full_name); ?></td>
        </tr>
        <tr>
            <th>Phone Number</th>
            <td><?php echo e($shipping->phone_number); ?></td>
        </tr>
    </table>
    <h1>Product Info</h1>
    <table border="1">
        <tr>
            <th>Sl No</th>
            <th>Product Id</th>
            <th>Product Name</th>
            <th>Product Price</th>
            <th>Product Quantity</th>
            <th>Total Price</th>
        </tr>
        <?php ($i=1); ?>
        <?php $__currentLoopData = $orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($i++); ?></td>
                <td><?php echo e($orderDetail->product_id); ?></td>
                <td><?php echo e($orderDetail->product_name); ?></td>
                <td>TK. <?php echo e($orderDetail->product_price); ?></td>
                <td><?php echo e($orderDetail->product_quantity); ?></td>
                <td>TK. <?php echo e($orderDetail->product_price*$orderDetail->product_quantity); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

</body>
</html>