<h1>Hello Dear {{ $firstName.' '.$lastName }}</h1>
Thanks for join our community....
Your email address is: {{ $email }}
Your Mobile number: {{ $phoneNo }}

Thanks By...
New Shop Team